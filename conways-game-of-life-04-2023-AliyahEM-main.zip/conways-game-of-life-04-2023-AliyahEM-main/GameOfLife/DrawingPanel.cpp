#include "DrawingPanel.h"
#include "wx/graphics.h"
#include "wx/dcbuffer.h"

wxBEGIN_EVENT_TABLE(DrawingPanel, wxPanel) 
        EVT_PAINT(DrawingPanel::OnPaint)
	    EVT_LEFT_UP(DrawingPanel::OnMouseUp)
wxEND_EVENT_TABLE() 

DrawingPanel::~DrawingPanel()
{
	// Any necessary clean-up code goes here
}

DrawingPanel::DrawingPanel(wxWindow* parent, std::vector<std::vector<bool>>& gameBoard) :wxPanel(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE), gameBoard(gameBoard)
{

	this->SetBackgroundStyle(wxBG_STYLE_PAINT);
	//this->Bind(wxEVT_PAINT, &DrawingPanel::OnPaint, this);
	//this->Bind(wxEVT_LEFT_UP, &DrawingPanel::OnMouseUp, this);//
	
}
//DrawingPanel::DrawingPanel(wxWindow* parent, std::vector<std::vector<bool>>& gameBoard) :wxPanel(parent, wxID_ANY, wxDefaultPosition, wxDefaultSize, wxBORDER_NONE), gameBoard(gameBoard){
//}

void DrawingPanel::OnPaint(wxPaintEvent& event)
{
	wxAutoBufferedPaintDC dc(this);
	dc.Clear();
	//ponter below!
	wxGraphicsContext* context = wxGraphicsContext::Create(dc);

	if (!context) { return; }

    // Drawing code goes here
    int panelWidth, panelHeight;
	GetSize(&panelWidth, &panelHeight);
	int cellSize = std::min(panelWidth / gridSize, panelHeight / gridSize);

	for (int row = 0; row < gridSize; row++)
	{
		for (int col = 0; col < gridSize; col++)
		{
			int x1 = col * cellSize;   
			int y1 = row * cellSize;   

			// Check corresponding bool from game board
			if (gameBoard[row][col] == true)
			{
				context->SetBrush(*wxLIGHT_GREY_BRUSH);
			}
			else
			{
				context->SetBrush(*wxWHITE_BRUSH);
			}

			context->SetPen(*wxBLACK_PEN); 
		 	context->DrawRectangle(x1, y1, cellSize, cellSize);  
		}    
	} 
}
//////////////////////////////////////////
void DrawingPanel::SetSize(wxSize& siz)
{
	wxPanel::SetSize(siz); //<-stinky code!//
	Refresh();
}
////////////////////////////////////////////


void DrawingPanel::OnMouseUp(wxMouseEvent& event) ///math may be off...
{
	int x = event.GetX(); 
	int y = event.GetY(); 
	int width, height;
	GetSize(&width, &height); 
	width /= gameBoard[0].size(); 
	height /= gameBoard.size(); 
	int row = y / height; 
	int col = x / width; 
	if (gameBoard[row][col]) { 
		gameBoard[row][col] = false; 
	}
	else {
		gameBoard[row][col] = true; 
	}
	Refresh();
}
