#pragma once
#include "wx/wx.h"
#include "DrawingPanel.h"
#include <wx/timer.h>

class MainWindow : public wxFrame
{
public:
	MainWindow();
	~MainWindow();
	

	wxDECLARE_EVENT_TABLE();

private:

	
	wxBoxSizer* sizer;
	void OnSizeChange(wxSizeEvent& event);
	DrawingPanel* drawingPanel;

	// Game board
	std::vector<std::vector<bool>> gameBoard;

	// Grid size
	int gridSize = 15;

	// Initialize the game board
	void initGameBoard();

	// Set the grid size
	void setGridSize(int newSize);

	void UpdateStatusBar();//

	int generation;
	int livingCells;
	wxStatusBar* statusBar; 

	wxToolBar* toolbar;
	void OnPlayButton(wxCommandEvent& event);
	void OnPauseButton(wxCommandEvent& event);
	void OnNextButton(wxCommandEvent& event);
	void OnTrashButton(wxCommandEvent& event);

	int countLivingNeighbors(int row, int col);

	void nextGeneration();

	wxTimer* m_timer;
	int m_timerInterval;
	void OnTimer(wxTimerEvent& event); 
	wxButton* m_playButton; 
	wxButton* m_pauseButton;


};
