#pragma once
#include "wx/wx.h"
class DrawingPanel : public wxPanel
{
public:
	/*DrawingPanel(wxWindow* parent);*/
	DrawingPanel(wxWindow* parent, std::vector<std::vector<bool>>& board);
    ~DrawingPanel();

	void OnPaint(wxPaintEvent& event);
	void SetSize(wxSize& sz);
	
	
	void OnMouseUp(wxMouseEvent& event);
	wxDECLARE_EVENT_TABLE();
private:
	
	int gridSize = 15;
	int cellSize = 10;

	std::vector<std::vector<bool>>& gameBoard;

};
