#include "App.h"
#include "MainWindow.h"

wxIMPLEMENT_APP(App);

App::App() {

}

App::~App() {

}

bool App::OnInit() {
	mainWindow = new MainWindow();
	mainWindow->Show();//Allows window to be shown
	return true;
}