#include "SettingsDialog.h"


wxBEGIN_EVENT_TABLE(SettingsDialog, wxDialog)
EVT_SPINCTRL(ID_SPINCTRL1, SettingsDialog::OnSpinCtrl1)
EVT_SPINCTRL(ID_SPINCTRL2, SettingsDialog::OnSpinCtrl2)
EVT_COLOURPICKER_CHANGED(ID_COLOURPICKER1, SettingsDialog::OnColourPicker1)
EVT_COLOURPICKER_CHANGED(ID_COLOURPICKER2, SettingsDialog::OnColourPicker2)
wxEND_EVENT_TABLE()

void SettingsDialog::OnSpinCtrl1(wxSpinEvent& event)
{
    int value = event.GetPosition();
    settings->SetSetting1(value);
}

void SettingsDialog::OnColourPicker1(wxColourPickerEvent& event)
{
    wxColour value = event.GetColour();
    settings->SetColourSetting1(value);
}

//void SettingsDialog::OnSpinCtrl(wxSpinEvent& event)
//{
//    
//    
//}
//
//void SettingsDialog::OnColourPickerChanged(wxColourPickerEvent& event)
//{
//   
//}

