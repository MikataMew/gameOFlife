#pragma once

#include "wx/wx.h"
#include "MainWindow.h"

class App : public wxApp
{
private:

	MainWindow* mainWindow;

public:
	App();//was here B4
	~App();//was here b4

	virtual bool OnInit();
};

