#pragma once
#include "wx/wx.h"
#include <wx/spinctrl.h>
#include <wx/clrpicker.h>
#include "Settings.h"
class SettingsDialog : public wxDialog
{
public:


    /*SettingsDialog(wxWindow* parent, Settings* settings) : wxDialog(parent, wxID_ANY, "Settings")*/
    SettingsDialog(wxWindow* parent, wxWindowID id, const wxString& title, wxWindow* window): wxDialog(parent, id, title, wxDefaultPosition, wxDefaultSize, wxDEFAULT_DIALOG_STYLE | wxRESIZE_BORDER), m_window(window)
    {

        // Initialize the dialog controls
        InitControls();

        // Create a main box sizer that will store a series of box sizers that stack controls horizontally
        wxBoxSizer* mainSizer = new wxBoxSizer(wxVERTICAL);
        // Create child box sizers that stack controls horizontally
        wxBoxSizer* childSizer1 = new wxBoxSizer(wxHORIZONTAL);
        wxBoxSizer* childSizer2 = new wxBoxSizer(wxHORIZONTAL);
        // Add child box sizers to the main box sizer
        mainSizer->Add(childSizer1, 0, wxALL, 5);
        mainSizer->Add(childSizer2, 0, wxALL, 5);
        // Add labels and controls to the child box sizers
        wxStaticText* label1 = new wxStaticText(this, wxID_ANY, "Setting 1:");
        wxSpinCtrl* spinCtrl1 = new wxSpinCtrl(this, wxID_ANY);
        childSizer1->Add(label1, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 5);
        childSizer1->Add(spinCtrl1, 0, wxALIGN_CENTER_VERTICAL);

        wxStaticText* label2 = new wxStaticText(this, wxID_ANY, "Setting 2:");
        wxTextCtrl* textCtrl1 = new wxTextCtrl(this, wxID_ANY);
        childSizer2->Add(label2, 0, wxALIGN_CENTER_VERTICAL | wxRIGHT, 5);
        childSizer2->Add(textCtrl1, 0, wxALIGN_CENTER_VERTICAL);
        
        SetSizer(mainSizer);

        // Add a button sizer to the dialog box that contains buttons for OK and CANCEL
        wxSizer* buttonSizer = CreateButtonSizer(wxOK | wxCANCEL);
        mainSizer->Add(buttonSizer, 0, wxALIGN_RIGHT | wxALL, 5);

        // Set the values of the controls from the settings object pointer

        spinCtrl1->SetValue(settings->GetSetting1());
        textCtrl1->SetValue(settings->GetSetting2());
    }



    wxDECLARE_EVENT_TABLE(); 
private:

    void InitControls()
    {
        // Create a box sizer that stacks controls vertically
        wxBoxSizer* sizer = new wxBoxSizer(wxVERTICAL);

        // Add controls to the sizer
        
        wxStaticText* label = new wxStaticText(this, wxID_ANY, "Settings:");
        sizer->Add(label, 0, wxALL, 5);
        wxCheckBox* checkbox = new wxCheckBox(this, wxID_ANY, "Option 1");
        sizer->Add(checkbox, 0, wxALL, 5);
        wxTextCtrl* textctrl = new wxTextCtrl(this, wxID_ANY, "Default value");
        sizer->Add(textctrl, 0, wxALL, 5);
        
        // ...


        // Set the sizer for the dialog
        SetSizer(sizer);
    } 
    
    wxWindow* m_window;

    /*wxSpinCtrl* m_spinCtrl;
    wxColourPickerCtrl* m_colourPickerCtrl;
    
    wxBoxSizer* m_mainSizer;*/
    
    Settings* settings;
    static const int ID_SPINCTRL1 = wxID_HIGHEST + 1;
    static const int ID_SPINCTRL2 = wxID_HIGHEST + 2;
    static const int ID_COLOURPICKER1 = wxID_HIGHEST + 3;
    static const int ID_COLOURPICKER2 = wxID_HIGHEST + 4;

    /*void OnSpinCtrl(wxSpinEvent& event);
    void OnColourPickerChanged(wxColourPickerEvent& event); */
    void OnSpinCtrl1(wxSpinEvent& event);
    void OnSpinCtrl2(wxSpinEvent& event);
    void OnColourPicker1(wxColourPickerEvent& event);
    void OnColourPicker2(wxColourPickerEvent& event);


};


