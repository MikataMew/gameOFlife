#include "MainWindow.h"
#include "play.xpm"
#include "pause.xpm"
#include "next.xpm"
#include "trash.xpm"
#include "SettingsDialog.h"


wxBEGIN_EVENT_TABLE(MainWindow, wxFrame) 
        EVT_SIZE(MainWindow::OnSizeChange)
    EVT_MENU(10001, MainWindow::OnPlayButton)
    EVT_MENU(10002, MainWindow::OnPauseButton)
    EVT_MENU(10003, MainWindow::OnNextButton)
    EVT_MENU(10004, MainWindow::OnTrashButton)
    EVT_MENU(10005, MainWindow::OnSettings)
    EVT_TIMER(wxID_ANY, MainWindow::OnTimer)
    

wxEND_EVENT_TABLE() 

MainWindow::~MainWindow() {
	// Empty destructor
}

//Creates the window visually.
MainWindow::MainWindow() : wxFrame(nullptr, wxID_ANY, "Game of Life", wxPoint(0, 0), wxSize(200, 200)) 
{
    // Initialize the status bar
	this->statusBar = this->CreateStatusBar();
    
    // create panel
	drawingPanel = new DrawingPanel(this, gameBoard);

    // create box sizer
    sizer = new wxBoxSizer(wxVERTICAL);

    // add panel to box sizer with appropriate flags
    sizer->Add(drawingPanel, 1, wxEXPAND | wxALL);

    // set window sizer
    this->SetSizer(sizer);

    // bind window resize event
    //this->Bind(wxEVT_SIZE, &MainWindow::OnSizeChange, this);////////////////

    // Initialize the game board
    initGameBoard(); 

    
    // Create the toolbar
    toolbar = CreateToolBar();

    // Add play button
    wxBitmap playIcon(play_xpm);
    toolbar->AddTool(10001, "Play", playIcon);

    // Add pause button
    wxBitmap pauseIcon(pause_xpm);
    toolbar->AddTool(10002, "Pause", pauseIcon);

    // Add next button
    wxBitmap nextIcon(next_xpm);
    toolbar->AddTool(10003, "Next", nextIcon);

    // Add trash button
    wxBitmap trashIcon(trash_xpm);
    toolbar->AddTool(10004, "Trash", trashIcon);

    // Realize the toolbar
    toolbar->Realize();



    m_playButton = new wxButton(this, wxID_ANY, "Play", wxPoint(10, 10), wxDefaultSize); 
    m_pauseButton = new wxButton(this, wxID_ANY, "Pause", wxPoint(100, 10), wxDefaultSize); 

    m_timer = new wxTimer(this, wxID_ANY); 
    m_timerInterval = 50; 

    drawingPanel->setSettings(&m_settings);
 
    wxMenuBar* menuBar = new wxMenuBar(); 
    wxMenu* optionsMenu = new wxMenu();
    
    enum 
    {
        ID_SETTINGS = wxID_HIGHEST + 1
    };
    optionsMenu->Append(ID_SETTINGS, "Settings");
    SetMenuBar(menuBar);
    menuBar->Append(optionsMenu, "Options");


}
 
void MainWindow::OnSizeChange(wxSizeEvent& event)
{
    // get size of window
    wxSize siz = event.GetSize();

    // call set size on panel
    if (drawingPanel != nullptr)
    {
        drawingPanel->SetSize(siz);
    }
    
    // skip event
    event.Skip();
}
//
void MainWindow::initGameBoard() 
{
    // Resize the game board vector to the grid size
    gameBoard.resize(m_settings.gridSize);

    // Resize each sub-vector to the grid size
    for (int i = 0; i < m_settings.gridSize; i++)
    {
        gameBoard[i].resize(m_settings.gridSize);
    }
}

void MainWindow::setGridSize(int newSize) 
{
    // Update the grid size variable
    m_settings.gridSize = newSize;

    // Reinitialize the game board with the new size
    initGameBoard();
}
void MainWindow::UpdateStatusBar()
{
    this->statusBar->SetStatusText("Generation: " + std::to_string(generation) + "   Living Cells: " + std::to_string(livingCells));
    this->Layout();///////////////////////////////////////
}

void MainWindow::OnPlayButton(wxCommandEvent& event)
{
    //TODO: Implement play button event handler
    m_timer->Start(m_timerInterval);

}
void MainWindow::OnPauseButton(wxCommandEvent& event)
{
    //TODO: Implement pause button event handler
    m_timer->Stop();

}
void MainWindow::OnTimer(wxTimerEvent& event)
{
    nextGeneration();
}
void MainWindow::OnNextButton(wxCommandEvent& event)
{
    //TODO: Implement next button event handler
    nextGeneration();//////////////////////////////////////////

}
void MainWindow::OnTrashButton(wxCommandEvent& event)
{
    //TODO: Implement trash button event handler
    // Reset the game board to all values being false
    for (int i = 0; i < m_settings.gridSize; i++) {
        for (int j = 0; j < m_settings.gridSize; j++) {
            gameBoard[i][j] = false;
        }
    }
    // Reset the living cell count and generation count to zero
    livingCells = 0;
    generation = 0;

    // Refresh the drawing panel
    drawingPanel->Refresh();
}


int MainWindow::countLivingNeighbors(int row, int col) ////////////////////////////////////
{
   int count = 0;

   // Nested loops to iterate through the neighboring cells
   for (int i = row - 1; i <= row + 1; i++) 
   {
       for (int j = col - 1; j <= col + 1; j++) 
       {
           // Skip the current cell
           if (i == row && j == col) 
           {
               continue;
           }

           // Check if the neighboring cell exists and is alive
           if (i >= 0 && i < row && j >= 0 && j < col)
           {
               count++;
           }
       }
   }

   return count;
}

void MainWindow::nextGeneration()//////////////////////////////////////
{
    // Step 1
    std::vector<std::vector<bool>> sandbox;
    sandbox.resize(gameBoard.size());
    for (auto& row : sandbox) 
    {
        row.resize(gameBoard[0].size());
    }
    // Step 2
    int livingCount = 0;
    for (int i = 0; i < gameBoard.size(); i++) {
        for (int j = 0; j < gameBoard[0].size(); j++) {
            int neighbors = countLivingNeighbors(i, j);
            if (gameBoard[i][j]) {
                if (neighbors < 2 || neighbors > 3) {
                    sandbox[i][j] = false;
                }
                else {
                    sandbox[i][j] = true;
                    livingCount++;
                }
            }
            else {
                if (neighbors == 3) {
                    sandbox[i][j] = true;
                    livingCount++;
                }
                else {
                    sandbox[i][j] = false;
                }
            }
        }
    }
    // Step 5
    gameBoard.swap(sandbox);

    // Step 6
    generation++;
    UpdateStatusBar();
    Refresh();
}

void MainWindow::OnSettings(wxCommandEvent& event)
{
    SettingsDialog* dialog = new SettingsDialog(this, m_settings);
    int result = dialog->ShowModal();
    if (result == wxID_OK) 
    {
        initGameBoard();
        drawingPanel->Refresh();
    }
}

// When the checkbox is clicked, update the setting object
//void MainWindow:: OnShowNeighborCountChecked(wxCommandEvent& event)
//{
//    bool showNeighborCount = showNeighborCountCheckbox->IsChecked();
//    m_settings.setShowNeighborCount(showNeighborCount);
//}

