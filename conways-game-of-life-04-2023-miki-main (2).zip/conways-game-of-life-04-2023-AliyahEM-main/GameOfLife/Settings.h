#pragma once
#include "wx/wx.h"
#include <fstream>


struct Settings 
{
    unsigned int livingCellRed = 128, livingCellGreen = 128, livingCellBlue = 128, livingCellAlpha = 255;
    unsigned int deadCellRed = 255, deadCellGreen = 255, deadCellBlue = 255, deadCellAlpha = 255;

    unsigned int gridSize = 15;
    unsigned int interval = 50; 

    wxColour gridColor = *wxBLACK;
    wxColour backgroundColor = *wxWHITE;

    wxColor getLivingCellColor() const 
    {
        return wxColor(livingCellRed, livingCellGreen, livingCellBlue, livingCellAlpha);
    }

    wxColor getDeadCellColor() const 
    {
        return wxColor(deadCellRed, deadCellGreen, deadCellBlue, deadCellAlpha);
    }

    void setLivingCellColor(const wxColor& color) {
        livingCellRed = color.Red();
        livingCellGreen = color.Green();
        livingCellBlue = color.Blue();
        livingCellAlpha = color.Alpha();
    }

    void setDeadCellColor(const wxColor& color) {
        deadCellRed = color.Red();
        deadCellGreen = color.Green();
        deadCellBlue = color.Blue();
        deadCellAlpha = color.Alpha();
    }
//public:
    /*int GetSetting1() const { return setting1; }
    void SetSetting1(int value) { setting1 = value; }

    wxString GetSetting2() const { return setting2; }
    void SetSetting2(const wxString& amp; value) { setting2 = value; }

    wxColour GetColourSetting1() const { return colourSetting1; }
    void SetColourSetting1(const wxColour& amp; value) { colourSetting1 = value; }*/


    //// Add two new methods for saving and loading settings data
    //void SaveSettings() 
    //{
    //    std::ofstream file("settings.bin", std::ios::out | std::ios::binary);
    //    file.write((char*)this, sizeof(Settings));
    //    file.close();
    //}

    //void LoadSettings() 
    //{
    //    std::ifstream file("settings.bin", std::ios::binary | std::ios::in);
    //    file.read((char*)this, sizeof(Settings));
    //    file.close();
    //}

//private:
//    int setting1;
//    wxString setting2;
//    wxColour colourSetting1;
};